package au.com.trgtd.tr.sync.iphone;

import au.com.trgtd.tr.services.Services;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import tr.model.Data;
import tr.model.DataLookup;
import tr.model.action.Action;
import tr.model.context.Context;
import tr.model.topic.Topic;

public abstract class SyncHandler {

    protected final static Logger LOG = Logger.getLogger(SyncHandler.class.getName());
    protected static final DateFormat DF = new SimpleDateFormat("yyyyMMdd");
    protected static final DateFormat DF_HHmm = new SimpleDateFormat("HHmm");
    protected final BufferedReader in;
    protected final PrintWriter out;
    protected final SyncProgress progress;
    protected boolean cancelSyncing;
    protected int nbrThoughtsToGet;
    protected int nbrActionsToGet;
    protected int nbrActionsGot;
    protected int nbrThoughtsGot;
    protected int nbrContextsToSend;
    protected int nbrContextsSent;
    protected int nbrTopicsToSend;
    protected int nbrTopicsSent;
    protected int nbrActionsToSend;
    protected int nbrActionsSent;
    protected int nbrTimesToSend;
    protected int nbrTimesSent;
    protected int nbrEnergiesToSend;
    protected int nbrEnergiesSent;
    protected int nbrPrioritiesToSend;
    protected int nbrPrioritiesSent;

    public SyncHandler(BufferedReader in, PrintWriter out, SyncProgress progress) {
        this.in = in;
        this.out = out;
        this.progress = progress;
    }

    protected void cancel() {
        this.cancelSyncing = true;
    }
    private Data data;

    protected Data getData() {
        if (data == null) {
            data = DataLookup.instance().lookup(Data.class);
        }
        return data;
    }
    private List<Context> contexts;

    protected List<Context> getContexts() {
        if (contexts == null) {
            if (getData() == null) {
                contexts = Collections.emptyList();
            } else {
                contexts = getData().getContextManager().list();
            }
        }
        return contexts;
    }
    private Boolean usesTime;

    protected boolean isTimeUsed() {
        if (usesTime == null) {
            usesTime = getData() != null && getData().getTimeCriterion().isUse();
        }
        return usesTime;
    }
    private Boolean usesEnergy;

    protected boolean isEnergyUsed() {
        if (usesEnergy == null) {
            usesEnergy = getData() != null && getData().getEnergyCriterion().isUse();
        }
        return usesEnergy;
    }
    private Boolean usesPriority;

    protected boolean isPriorityUsed() {
        if (usesPriority == null) {
            usesPriority = getData() != null && getData().getPriorityCriterion().isUse();
        }
        return usesPriority;
    }
    private List<Topic> topics;

    protected List<Topic> getTopics() {
        if (topics == null) {
            if (getData() == null) {
                topics = Collections.emptyList();
            } else {
                topics = getData().getTopicManager().list();
            }
        }
        return topics;
    }
    protected List<Action> actions;

    protected List<Action> getActions() {
        if (actions == null) {
            actions = Services.instance.getAllActions();
            for (Iterator<Action> iterator = actions.iterator(); iterator.hasNext();) {
                Action action = iterator.next();
                if (action.isDone() || !action.isStateASAP()) {
                    iterator.remove();
                }
            }
        }
        return actions;
    }

    protected void updateActionsToSend() {
        if (actions == null) {
            return;
        }
        for (Iterator<Action> iterator = actions.iterator(); iterator.hasNext();) {
            Action action = iterator.next();
            if (action.isDone()) {
                iterator.remove();
            }
        }
    }

    protected Topic getTopic(String idString) {
        if (idString == null || idString.length() < 1) {
            return Topic.getDefault();
        }
        try {
            int id = Integer.parseInt(idString);
            for (Topic topic : data.getTopicManager().list()) {
                if (topic.getID() == id) {
                    return topic;
                }

            }
            throw new IllegalArgumentException();
        } catch (Exception ex) {
            System.out.println("ERROR Invalid Topic ID: " + idString);
        }
        return Topic.getDefault();
    }

    protected void updateProgress(int done, int todo) {
        if (todo > 0) {
            int percent = (done / todo) * 100;
            progress.setProgress(percent > 100 ? 100 : percent);
        } else {
            progress.setProgress(0);
        }
    }

    protected static synchronized String log(String x) {
        LOG.log(Level.INFO, "Sent:{0}", x);
        return x;
    }

    protected String getTimeID(Action action) {
        return action.getTime() == null ? "" : "" + action.getTime().getID();
    }

    protected String getEnergyID(Action action) {
        return action.getEnergy() == null ? "" : "" + action.getEnergy().getID();
    }

    protected String getPriorityID(Action action) {
        return action.getPriority() == null ? "" : "" + action.getPriority().getID();
    }
}


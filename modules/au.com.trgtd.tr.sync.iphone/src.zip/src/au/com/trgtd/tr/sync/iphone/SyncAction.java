package au.com.trgtd.tr.sync.iphone;

import java.awt.EventQueue;
import java.awt.Frame;
import org.openide.util.HelpCtx;
import org.openide.util.Lookup;
import org.openide.util.LookupEvent;
import org.openide.util.LookupListener;
import org.openide.util.NbBundle;
import org.openide.util.actions.CallableSystemAction;
import org.openide.windows.WindowManager;
import tr.model.Data;
import tr.model.DataLookup;

public final class SyncAction extends CallableSystemAction {

    /** Constructor. */
    public SyncAction() {
        super();
        dataChanged();
        Lookup.Result r = DataLookup.instance().lookup(new Lookup.Template(Data.class));
        r.addLookupListener(new LookupListener() {
            public void resultChanged(LookupEvent lookupEvent) {
                dataChanged();
            }
        });
    }

    private void dataChanged() {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                Data data = DataLookup.instance().lookup(Data.class);
                setEnabled(data != null);
            }
        });
    }

    @Override
    public void performAction() {
        if (SyncManager.getDefault().canStartSync()) {
            Frame frame = WindowManager.getDefault().getMainWindow();
            (new SyncDialog(frame)).setVisible(true);
        }
    }

    @Override
    public String getName() {
        return NbBundle.getMessage(this.getClass(), "CTL_SyncAction");
    }

    @Override
    public HelpCtx getHelpCtx() {
        return HelpCtx.DEFAULT_HELP;
    }

    @Override
    protected String iconResource() {
        return "au/com/trgtd/tr/sync/iphone/iphone.png";
    }

    @Override
    protected boolean asynchronous() {
        return false;
    }

}

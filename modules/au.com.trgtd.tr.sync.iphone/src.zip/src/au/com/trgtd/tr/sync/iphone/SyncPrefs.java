/*
 * The contents of this file are subject to the terms of the Common Development
 * and Distribution License (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can get a copy of the License at http://www.thinkingrock.com.au/cddl.html
 * or http://www.thinkingrock.com.au/cddl.txt.
 *
 * When distributing Covered Code, include this CDDL Header Notice in each file
 * and include the License file at http://www.thinkingrock.com.au/cddl.txt.
 * If applicable, add the following below the CDDL Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * The Original Software is ThinkingRock. The Initial Developer of the Original
 * Software is Avente Pty Ltd, Australia.
 *
 * Portions Copyright 2006-2007 Avente Pty Ltd. All Rights Reserved.
 */

package au.com.trgtd.tr.sync.iphone;

import au.com.trgtd.tr.appl.Constants;
import java.util.logging.Logger;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * User preferences for the iPhone sync.
 *
 * @author Jeremy Moore (jimoore@netspace.net.au)
 */
public class SyncPrefs {
    
    private static final Logger LOG = Logger.getLogger("tr.sync.iphone.prefs");
    private static final Preferences prefs = Preferences.userRoot().node(Constants.PREFS_PATH_NEW + "/iphonesync");
    private static final String KEY_PORT = "port";
    private static final int DEF_PORT = 5000;
    private static final String KEY_LAST_ADDR = "last.addr";
    private static final String KEY_LAST_NAME = "last.name";
    
    /**
     * Gets the value for the port preference.
     * @return The value.
     */
    public static final int getPort() {
        return prefs.getInt(KEY_PORT, DEF_PORT);
    }
    
    /**
     * Sets the value for the port preference.
     * @param value The value.
     */
    public static final void setPort(int value) {
        prefs.putInt(KEY_PORT, value);
        flush();
    }

    /**
     * Gets the value for the last used IP address.
     * @return The value.
     */
    public static final String getLastAddr() {
        String addr = prefs.get(KEY_LAST_ADDR, "");
        return addr == null ? "" : addr;
    }

    /**
     * Sets the value for the last used IP address.
     * @param value The value.
     */
    public static final void setLastAddr(String value) {
        prefs.put(KEY_LAST_ADDR, value);
        flush();
    }

    /**
     * Gets the value for the last used address name.
     * @return The value.
     */
    public static final String getLastName() {
        String name = prefs.get(KEY_LAST_NAME, "");
        return name == null ? "" : name;
    }

    /**
     * Sets the value for the last used address name.
     * @param value The value.
     */
    public static final void setLastName(String value) {
        prefs.put(KEY_LAST_NAME, value);
        flush();
    }
       
    private static void flush() {
        try {
            prefs.flush();
        } catch (BackingStoreException ex) {
            LOG.severe("GUI preferences error. " + ex.getMessage());
        }
    }
    
}
